﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextOption : MonoBehaviour {

    public int mIndex;
    public Text mText;
    public List<Requirement> mRequirements;

    public void Init(int index, string text)
    {
        mIndex = index;
        mText.text = text;
        mRequirements = new List<Requirement>();
    }

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void AddRequirement(Requirement requirement)
    {
        mRequirements.Add(requirement);
        Refresh();
    }

    void Refresh()
    {
        if(!AreRequirementsSatisfied())
        {
            mText.color = GameManager.mInstance.mInactiveTextColor;
        }
    }

    bool AreRequirementsSatisfied()
    {
        foreach (Requirement req in mRequirements)
        {
            if (!req.IsSatisfied())
            {
                return false;
            }
        }

        return true;
    }

    public void OnClicked()
    {
        if(!AreRequirementsSatisfied())
        {
            return;
        }

        GameManager.mInstance.OnClickedOption(this);
    }
}
