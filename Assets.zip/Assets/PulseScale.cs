﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PulseScale : MonoBehaviour {

    float mBaseScale;

	// Use this for initialization
	void Start () {
        mBaseScale = transform.localScale.x;
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 scale = Vector3.one * (mBaseScale + 0.3f * Mathf.Sin(Time.time));
        transform.localScale = scale;
	}
}
