﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Requirement {

    public virtual bool IsSatisfied() { return false; }
}

public class PowerRequirement : Requirement
{
    int mPowerRequired;
    ClassType mPowerTypeRequired;

    public PowerRequirement(ClassType type, int amt)
    {
        mPowerRequired = amt;
        mPowerTypeRequired = type;
    }

    public override bool IsSatisfied()
    {
        int currentAmt = GameManager.mInstance.GetTotalPower(mPowerTypeRequired);
        if(currentAmt >= mPowerRequired)
        {
            return true;
        }

        return false;
    }
}

public class CrewNumRequirement : Requirement
{
    int mNumRequired;
    ClassType mClassTypeRequired;

    public CrewNumRequirement(ClassType type, int amt)
    {
        mNumRequired = amt;
        mClassTypeRequired = type;
    }

    public override bool IsSatisfied()
    {
        int currentAmt = GameManager.mInstance.GetNumCrewOfType(mClassTypeRequired);
        if (currentAmt >= mNumRequired)
        {
            return true;
        }

        return false;
    }
}

public class CargoRequirement : Requirement
{
    public CargoRequirement()
    {
    }

    public override bool IsSatisfied()
    {
        if (GameManager.mInstance.HasCargo())
        {
            return true;
        }

        return false;
    }
}

public class CreditsRequirement : Requirement
{
    int mNumRequired;

    public CreditsRequirement(int amt)
    {
        mNumRequired = amt;
    }

    public override bool IsSatisfied()
    {
        int currentAmt = GameManager.mInstance.GetNumCredits();
        if (currentAmt >= mNumRequired)
        {
            return true;
        }

        return false;
    }
}
