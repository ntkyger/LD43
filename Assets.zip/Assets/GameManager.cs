﻿using System.Collections;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

[System.Serializable]
public class TraitData
{
    public string mName;
    public TraitType mTraitType;
    public string mSubtitle;
    public Color mSubtitleColor;
    public string mTooltipDescription;
    public Sprite mSprite;
}

public enum GameState
{
    None,
    EncounterMode,
    MapMode,
    GameOver,
}

public class GameManager : MonoBehaviour {

    public List<TraitData> mTraitData;
    Dictionary<TraitType, TraitData> mTraitDataMap;

    public Color mEmpathColor;
    public Color mEngineerColor;
    public Color mSecurityColor;

    public Color mBadTextColor;
    public Color mGoodTextColor;
    public Color mInactiveTextColor;

    // Manifest Panel
    public Transform mCrewGridContainer;
    public GameObject mCrewGridEntryPrefab;
    public Text mNumCrewText;
    public Text mNumCombatCrewText;
    public Text mNumEmpathCrewText;
    public Text mNumEngineerCrewText;
    public Text mCargoText;

    // Core Systems
    public GameObject mStabilityIndicator;
    public Transform mStabilityMarkerAnchor;
    public GameObject mMaxStabilityShroud;
    public Text mShipNameText;
    public Text mCreditsText;
    public Text mStabilityText;
    public Text mCombatPowerText;
    public Text mEmpathPowerText;
    public Text mEngineerPowerText;

    // Navigation
    public Transform mStarContainer;
    public Transform mOriginStarAnchor;
    public GameObject mStarPrefab;
    public GameObject mMapCover; // A semi-transparent shroud to provide visual cue that travel is not possible.
    public GameObject mCurrentStarIndicator;
    public Text mTimeText;
    public Text mTimeText2;
    public Text mTimeText3;

    // Encounter
    public Transform mEncounterContainer;
    public Text mEncounterTitle;
    public Text mEncounterDescription;
    public List<TextOption> mCurrentOptions;

    // Option Prefabs
    public GameObject Option_TextPrefab;

    // Info Panel
    public GameObject mInfoPanel;
    public Text mInfoText;

    public List<TextPlusColor> mEncounterLog;

    Star mCurrentStar;
    Encounter mCurrentEncounter;

    public GameObject mTooltip;
    public Text mTooltipText;

    public GameObject mCrewGameOverScreen;
    public GameObject mMutinyGameOverScreen;
    public GameObject mPauseMenu;

    public Canvas mCanvas;

    List<CrewMember> mCrew;
    int mMaxCrew = 5;

    GameState mCurrentMode;

    int mCurrentStability = 100;
    int mNumCredits = 0;
    int mCurrentDay = 1;


    static string[] randomCargo = { "Radioactive Isotopes", "Recycled Biomaterial", "Plums", "Dehydrated Meals", "Cryofrozen Insectoids", "Rocket Fuel", "Antimatter", "Quark-Gluon Plasma", "Unprocessed Beef", "Ice", "Anti-grav Equipment", "Biological Samples", "Silk Cabling", "Warp Drive Components", "High-Velocity Capacitors" };
    static string[] randomContraband = { "Addictive Substances", "Weapons-grade antimatter", "Viral Biotriggers", "Exotic Pets", "Espionage Malware", "Small Arms" };
    static string[] randomCargoUnit = { "Tons", "Cubic Meters of", "Furlongs", "Kiloliters", "Gallons", "Zettaflops", "Gigagrams" };
    string mCargoString;
    public bool mbHasCargo;
    public bool mbCargoIsContraband;

    public static GameManager mInstance;

    private void Awake()
    {
        mInstance = this;

        mTraitDataMap = new Dictionary<TraitType, TraitData>();
        foreach(TraitData traitData in mTraitData)
        {
            mTraitDataMap[traitData.mTraitType] = traitData;
        }

        mCrew = new List<CrewMember>();
        mCurrentOptions = new List<TextOption>();
        mEncounterLog = new List<TextPlusColor>();
    }

    // Use this for initialization
    void Start() {
        foreach (Transform child in mCrewGridContainer)
        {
            Destroy(child.gameObject);
        }

        for (int i = 0; i < 5; i++)
        {
            AddNewRandomCrewMember();
        }

        // Random ship name
        string[] alphabet = new string[26] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        mShipNameText.text = "Starship " + alphabet[Random.Range(0, alphabet.Length)] + Random.Range(0, 999) + "-" + alphabet[Random.Range(0, alphabet.Length)] + Random.Range(0, 99);

        // Random cargo
        mbHasCargo = true;
        mCargoString = GetRandomCargoString();

        RefreshTextFields();

        InitStars();
        mMapCover.SetActive(false);

        mCurrentMode = GameState.MapMode;
    }

    void RefreshTextFields()
    {
        mNumCrewText.text = mCrew.Count + "/" + mMaxCrew + " Crew";
        mNumCombatCrewText.text = GetNumCrewOfType(ClassType.Combat).ToString() + " Security";
        mNumEmpathCrewText.text = GetNumCrewOfType(ClassType.Empath).ToString() + " Empath";
        mNumEngineerCrewText.text = GetNumCrewOfType(ClassType.Engineer).ToString() + " Technician";
        if (!mbHasCargo)
        {
            mCargoString = "Cargo: None";
        }
        mCargoText.text = mCargoString;

        mCreditsText.text = "Credits: " + mNumCredits;
        mCombatPowerText.text = GetTotalPower(ClassType.Combat).ToString();
        mEmpathPowerText.text = GetTotalPower(ClassType.Empath).ToString();
        mEngineerPowerText.text = GetTotalPower(ClassType.Engineer).ToString();

        int maxStability = GetMaxStability();
        mCurrentStability = Mathf.Clamp(mCurrentStability, 0, maxStability);
        string stabilityText = mCurrentStability + "/" + maxStability;
        if(mCurrentStability <= 10)
        {
            stabilityText += " <Warning: Mutiny Imminent>";
            mStabilityText.color = mBadTextColor;
        }
        else
        {
            mStabilityText.color = mGoodTextColor;
        }
        mStabilityText.text = stabilityText;


        Vector3 stabilityMarkerPos = mStabilityMarkerAnchor.position;
        stabilityMarkerPos.x += (mCurrentStability / 100f) * 800f;
        mStabilityIndicator.transform.position = stabilityMarkerPos;

        if (maxStability >= 100)
        {
            mMaxStabilityShroud.SetActive(false);
        }
        else
        {
            mMaxStabilityShroud.SetActive(true);
            RectTransform rt = mMaxStabilityShroud.GetComponent<RectTransform>();
            float shroudAmount = ((100f - maxStability) / 100f) * 800f; // 800 is the pixel width of the mood bar.
            rt.sizeDelta = new Vector2(shroudAmount, rt.sizeDelta.y);
        }

        mTimeText.text = "Day " + mCurrentDay;
        mTimeText2.text = "Journey duration: " + mCurrentDay + " Days";
        mTimeText3.text = "Journey duration: " + mCurrentDay + " Days";
    }

    public int GetNumCrew()
    {
        return mCrew.Count;
    }

    public int GetMaxCrew()
    {
        return mMaxCrew;
    }

    public int GetNumCrewOfType(ClassType classType)
    {
        int numCrew = 0;
        foreach (CrewMember crewMember in mCrew)
        {
            if (crewMember.mClass == classType)
            {
                numCrew++;
            }
        }

        return numCrew;
    }

    public int GetTotalPower(ClassType classType)
    {
        int totalPower = 0;
        foreach(CrewMember crewMember in mCrew)
        {
            totalPower += crewMember.GetTotalClassPoints(classType);
        }

        return totalPower;
    }
	
	// Update is called once per frame
	void Update () {
        RefreshTextFields();

        if(Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }
	}

    public void TogglePauseMenu()
    {
        bool isPauseMenuActive = mPauseMenu.activeInHierarchy;
        mPauseMenu.SetActive(!isPauseMenuActive);
    }

    public void OnExitedEncounter()
    {
        mCurrentDay++;
        mCurrentMode = GameState.MapMode;
        mMapCover.gameObject.SetActive(false);

        // If this is the last star in the current thread, generate two new threads
        if (mCurrentStar.mChildStars.Count == 0)
        {
            InitStars();
        }

        // Clear all selected UI.
        foreach (Transform crewCardObj in mCrewGridContainer)
        {
            CrewGridEntry crewCard = crewCardObj.GetComponent<CrewGridEntry>();
            if (crewCard.IsSelected())
            {
                crewCard.ToggleSelected();
            }
        }

        // Clear encounter UI.
        foreach (TextOption option in mCurrentOptions)
        {
            Destroy(option.gameObject);
        }

        if (mCrew.Count > 0)
        {
            // Some crew members have traits that trigger when exiting an encounter.
            bool brainWorms = false;
            foreach (CrewMember crew in mCrew)
            {
                foreach (TraitType trait in crew.mTraits)
                {
                    switch (trait)
                    {
                        case TraitType.BrainWormHost:
                            brainWorms = true;
                            break;
                        case TraitType.Counselor:
                            IncrementStability(1);
                            Log("Crew gained 1 stability thanks to " + crew.GetFullName() + "'s counseling.", mGoodTextColor);
                            break;
                        case TraitType.Narcissist:
                            IncrementStability(-1);
                            Log("Crew lost 1 stability due to " + crew.GetFullName() + "'s narcissism.", mGoodTextColor);
                            break;
                        case TraitType.Sexy:
                            {
                                if (mCurrentEncounter.IsRestEncounter())
                                {
                                    IncrementStability(1);
                                    Log("Crew gained 1 stability thanks to " + crew.GetFullName() + "'s sexiness.", mGoodTextColor);
                                }
                                break;
                            }
                    }
                }
            }

            if (brainWorms)
            {
                // Pick a random crew member and try to override one of their traits.
                CrewMember crew = mCrew[Random.Range(0, mCrew.Count)];
                crew.TryAddBrainWorms();

                Log(crew.GetFullName() + " has been infected with brain worms!", mBadTextColor);
            }

            // Pick a random crew member to level up.
            CrewMember crewLevelUp = mCrew[Random.Range(0, mCrew.Count)];
            if (crewLevelUp.mClassLevel < 5)
            {
                crewLevelUp.mClassLevel++;
                Log(crewLevelUp.GetFullName() + " gained a level!", mGoodTextColor);
            }

            // Pick a random crew member to get a trait.
            CrewMember crewForTraits = mCrew[Random.Range(0, mCrew.Count)];
            if (crewForTraits.GetNumTraits() < 3)
            {
                TraitType newTrait = crewForTraits.GainRandomTrait();
                Log(crewForTraits.GetFullName() + " gained the trait: " + GetTraitName(newTrait) + ".", mGoodTextColor);
            }
        }

        // Fill in log
        StringBuilder logText = new StringBuilder();
        foreach (TextPlusColor logEntry in mEncounterLog)
        {
            logText.AppendLine(logEntry.mText);
            logText.AppendLine();
        }
        logText.AppendLine();
        logText.AppendLine("<Use the Navigation panel to select your next destination>");
        mEncounterDescription.text = logText.ToString();
        
        mCurrentEncounter = null;
        mEncounterTitle.text = "";

        CheckCrewStatus();
    }

    public void OnClickedStar(Star star)
    {
        if(mCurrentMode == GameState.MapMode)
        {
            if (mCurrentStar.mChildStars.Contains(star))
            {
                mCurrentStarIndicator.transform.position = star.transform.position;
                mCurrentStar = star;

                // Start new encounter
                StartEncounter(star);
            }
        }
    }

    void StartEncounter(Star star)
    {
        mCurrentMode = GameState.EncounterMode;
        mMapCover.gameObject.SetActive(true);

        Encounter encounter = star.GetEncounter();
        mCurrentEncounter = encounter;

        mEncounterTitle.text = mCurrentEncounter.GetEncounterTitle();
        mEncounterDescription.text = mCurrentEncounter.GetEncounterText();

        if(mCurrentEncounter.IsRestEncounter())
        {
            // Sell cargo and pick up new shipment
            if (GameManager.mInstance.HasCargo())
            {
                IncrementCredits(10);
            }
            PickUpCargo();

            // Gain 3 crew.
            for (int i = 0; i < 3; i++)
            {
                if (GetNumCrew() < GetMaxCrew())
                {
                    AddNewRandomCrewMember();
                }
            }
        }

        if(mCurrentOptions.Count > 0)
        {
            foreach(TextOption option in mCurrentOptions)
            {
                if (option != null)
                {
                    Destroy(option.gameObject);
                }
            }
        }

        List<TextOption> options = new List<TextOption>();
        options = mCurrentEncounter.GetOptions();
        mCurrentOptions = options;
        foreach(TextOption option in mCurrentOptions)
        {
            option.transform.SetParent(mEncounterContainer, false);
        }

        // Clear out log
        mEncounterLog = new List<TextPlusColor>();
    }

    void InitStars()
    {
        foreach(Transform starObj in mStarContainer)
        {
            Destroy(starObj.gameObject);
        }

        GameObject originStarObj = Instantiate(mStarPrefab);
        originStarObj.transform.SetParent(mStarContainer, false);
        originStarObj.transform.position = mOriginStarAnchor.position;
        Star originStar = originStarObj.GetComponent<Star>();
        originStar.Init();

        // Generate two paths: one up, one down.
        Vector3 topPos = mOriginStarAnchor.position + new Vector3(150, 50, 0) * mCanvas.scaleFactor;
        Star currentStar = originStar;

        for (int i = 0; i < 5; i++)
        {
            GameObject newStarObj = Instantiate(mStarPrefab);
            newStarObj.transform.SetParent(mStarContainer, false);
            newStarObj.transform.position = topPos;

            Star newStar = newStarObj.GetComponent<Star>();
            newStar.Init();
            newStar.SetParentStar(currentStar);
            currentStar.mChildStars.Add(newStar);

            currentStar = newStar;
            topPos += new Vector3(150, 0, 0) * mCanvas.scaleFactor;
        }

        Vector3 bottomPos = mOriginStarAnchor.position + new Vector3(150, -50, 0) * mCanvas.scaleFactor;
        currentStar = originStar;

        for (int i = 0; i < 5; i++)
        {
            GameObject newStarObj = Instantiate(mStarPrefab);
            newStarObj.transform.SetParent(mStarContainer, false);
            newStarObj.transform.position = bottomPos;

            Star newStar = newStarObj.GetComponent<Star>();
            newStar.Init();
            newStar.SetParentStar(currentStar);
            currentStar.mChildStars.Add(newStar);

            currentStar = newStar;
            bottomPos += new Vector3(150, 0, 0) * mCanvas.scaleFactor;
        }

        mCurrentStar = originStar;
        mCurrentStarIndicator.transform.position = originStar.transform.position;
    } 

    void AddNewRandomCrewMember()
    {
        CrewMember newMember = new CrewMember();
        //int numTraits = Random.Range(0, 4);
        //for (int i = 0; i < numTraits; i++)
        //{
        //    newMember.GainRandomTrait();
        //}
        AddCrewMember(newMember);
    }

    void AddCrewMember(CrewMember newMember)
    {
        mCrew.Add(newMember);

        GameObject crewCard = Instantiate(mCrewGridEntryPrefab);
        CrewGridEntry crewGridEntry = crewCard.GetComponent<CrewGridEntry>();
        crewGridEntry.Init(newMember);
        crewCard.transform.SetParent(mCrewGridContainer, false);

        newMember.mCard = crewGridEntry;
    }

    public int GetMaxStability()
    {
        int baseStability = 100;
        foreach(CrewMember crewMember in mCrew)
        {
            foreach (TraitType trait in crewMember.mTraits)
            {
                baseStability += GetTraitStabilityEffect(trait, crewMember);
            }
        }

        return baseStability;
    }

    public string GetClassName(ClassType classType)
    {
        switch (classType)
        {
            case ClassType.Combat:
                return "Security";
            case ClassType.Empath:
                return "Empath";
            case ClassType.Engineer:
                return "Technician";
        }

        return "None";
    }

    public Color GetClassColor(ClassType classType)
    {
        switch (classType)
        {
            case ClassType.Combat:
                return mSecurityColor;
            case ClassType.Empath:
                return mEmpathColor;
            case ClassType.Engineer:
                return mEngineerColor;
        }

        return Color.white;
    }

    public Sprite GetTraitSprite(TraitType trait)
    {
        TraitData data = GetTraitData(trait);
        return data.mSprite;
    }

    public string GetTraitName(TraitType trait)
    {
        TraitData data = GetTraitData(trait);
        return data.mName;
    }

    public int GetTraitStabilityEffect(TraitType trait, CrewMember crewMember)
    {
        switch (trait)
        {
            case TraitType.PoorHygiene:
                return -2;
            case TraitType.Confident:
                return 2;
            case TraitType.BrainWormHost:
                return -1;
            case TraitType.Insane:
                return -10;
            case TraitType.Sexy:
                return -5;
            case TraitType.Racist:
                {
                    // +1 max mood for every crew of same race, but -2 max mood for every crew of different species.
                    int numSameSpecies = 0;
                    int numDiffSpecies = 0;
                    foreach (CrewMember crew in mCrew)
                    {
                        if (crew == crewMember)
                        {
                            continue;
                        }

                        if (crew.mRace == crewMember.mRace)
                        {
                            numSameSpecies++;
                        }
                        else
                        {
                            numDiffSpecies++;
                        }
                    }

                    int effect = numSameSpecies - (2 * numDiffSpecies);
                    return effect;
                }
            case TraitType.Xenophile:
                {
                    // +1 max mood for every crew of different race, but -10 if all are same species.
                    int numSameSpecies = 0;
                    int numDiffSpecies = 0;
                    foreach (CrewMember crew in mCrew)
                    {
                        if (crew == crewMember)
                        {
                            continue;
                        }

                        if (crew.mRace == crewMember.mRace)
                        {
                            numSameSpecies++;
                        }
                        else
                        {
                            numDiffSpecies++;
                        }
                    }

                    int effect = numDiffSpecies;
                    if (effect == 0 && numSameSpecies > 0)
                    {
                        effect = -10;
                    }

                    return effect;
                }
            case TraitType.Antisocial:
                {
                    // -1 Max § for every other crew member, +2 for every other antisocial crew member.
                    int numOtherCrewMembers = mCrew.Count - 1;
                    int numAntisocial = 0;
                    foreach (CrewMember crew in mCrew)
                    {
                        if (crew == crewMember)
                        {
                            continue;
                        }

                        if (crew.HasTrait(TraitType.Antisocial))
                        {
                            numAntisocial++;
                        }
                    }

                    int effect = numAntisocial * 2 - numOtherCrewMembers;
                    return effect;
                }
            case TraitType.Lonely:
                {
                    // -10 Max §, but +1 Max § for every other crew member
                    int numOtherCrewMembers = mCrew.Count - 1;

                    int effect = numOtherCrewMembers - 10;
                    return effect;
                }
            case TraitType.Jealous:
                {
                    // -1 § for every other Sexy or Confident crew member.
                    int numSexyConfident = 0;
                    foreach (CrewMember crew in mCrew)
                    {
                        if (crew == crewMember)
                        {
                            continue;
                        }

                        if (crew.HasTrait(TraitType.Sexy) || crew.HasTrait(TraitType.Confident))
                        {
                            numSexyConfident++;
                        }
                    }

                    int effect = numSexyConfident * -1;
                    return effect;
                }
        }

        return 0;
    }

    public TextPlusColor GetTraitSubtitle(TraitType trait, CrewMember crewMember)
    {
        TraitData data = GetTraitData(trait);
        if (!string.IsNullOrEmpty(data.mSubtitle))
        {
            return new TextPlusColor(data.mSubtitleColor, data.mSubtitle);
        }

        switch (trait)
        {
            case TraitType.Diligent:
                {
                    // This trait generates +1 power for crew class.
                    string text = "+1 " + GetClassName(crewMember.mClass);
                    Color color = GetClassColor(crewMember.mClass);
                    return new TextPlusColor(color, text);
                }
            case TraitType.Racist:
                {
                    int effect = GetTraitStabilityEffect(trait, crewMember);
                    string text = effect.ToString() + " Max §";
                    Color color = mBadTextColor;
                    if (effect >= 0)
                    {
                        text = "+" + text;
                        color = mGoodTextColor;
                    }

                    return new TextPlusColor(color, text);
                }
            case TraitType.Xenophile:
                {
                    int effect = GetTraitStabilityEffect(trait, crewMember);
                    string text = effect.ToString() + " Max §";
                    Color color = mBadTextColor;
                    if (effect >= 0)
                    {
                        text = "+" + text;
                        color = mGoodTextColor;
                    }

                    return new TextPlusColor(color, text);
                }
            case TraitType.Antisocial:
                {
                    int effect = GetTraitStabilityEffect(trait, crewMember);
                    string text = effect.ToString() + " Max §";
                    Color color = mBadTextColor;
                    if (effect >= 0)
                    {
                        text = "+" + text;
                        color = mGoodTextColor;
                    }

                    return new TextPlusColor(color, text);
                }
            case TraitType.Lonely:
                {
                    int effect = GetTraitStabilityEffect(trait, crewMember);
                    string text = effect.ToString() + " Max §";
                    Color color = mBadTextColor;
                    if (effect >= 0)
                    {
                        text = "+" + text;
                        color = mGoodTextColor;
                    }

                    return new TextPlusColor(color, text);
                }
            case TraitType.Jealous:
                {
                    int effect = GetTraitStabilityEffect(trait, crewMember);
                    string text = effect.ToString() + " Max §";
                    Color color = mBadTextColor;
                    if (effect >= 0)
                    {
                        text = "+" + text;
                        color = mGoodTextColor;
                    }

                    return new TextPlusColor(color, text);
                }
        }

        return null;
    }

    public TraitData GetTraitData(TraitType traitType)
    {
        return mTraitDataMap[traitType];
    }

    public void ActivateTooltip(TraitType trait)
    {
        if(trait == TraitType.None)
        {
            mTooltip.gameObject.SetActive(false);
        }
        else
        {
            mTooltip.gameObject.SetActive(true);
        }

        Vector3 tooltipPos = Input.mousePosition;
        RectTransform rectTransform = mTooltip.GetComponent<RectTransform>();
        tooltipPos.x += mCanvas.scaleFactor * rectTransform.rect.width / 2 + 10;
        mTooltip.transform.position = tooltipPos;
        TraitData data = GetTraitData(trait);

        if (!string.IsNullOrEmpty(data.mTooltipDescription))
        {
            mTooltipText.text = data.mTooltipDescription;
        }
        else
        {
            // No tooltip to display.
            mTooltip.gameObject.SetActive(false);
        }
    }

    public void ActivateTooltip(RaceType race)
    {
        if (race == RaceType.None)
        {
            mTooltip.gameObject.SetActive(false);
        }
        else
        {
            mTooltip.gameObject.SetActive(true);
        }

        Vector3 tooltipPos = Input.mousePosition;
        RectTransform rectTransform = mTooltip.GetComponent<RectTransform>();
        tooltipPos.x += mCanvas.scaleFactor * rectTransform.rect.width / 2 + 10;
        mTooltip.transform.position = tooltipPos;

        mTooltipText.text = "This character is " + GetRaceText(race);
    }

    public void ActivateTooltip(Star star)
    {
        mTooltip.gameObject.SetActive(true);

        string text = "";
        text += star.mName + ".";

        if (star == mCurrentStar)
        {
            text += " You are here.";
        }

        if (mCurrentStar.mChildStars.Contains(star))
        {
            text += " Click to travel.";
        }

        Vector3 tooltipPos = Input.mousePosition;
        RectTransform rectTransform = mTooltip.GetComponent<RectTransform>();
        tooltipPos.x += mCanvas.scaleFactor * rectTransform.rect.width / 2 + 10;
        mTooltip.transform.position = tooltipPos;

        mTooltipText.text = text;
    }

    public string GetRaceText(RaceType race)
    {
        switch(race)
        {
            case RaceType.Human:
                return "Human";
            case RaceType.Cthulian:
                return "Cthulian";
            case RaceType.Insectoid:
                return "Insectoid";
            case RaceType.Reptilian:
                return "Reptilian";
        }

        return "Unknown";
    }

    public void DeactivateTooltip()
    {
        mTooltip.gameObject.SetActive(false);
    }

    public void OnClickedCrewCard(CrewGridEntry crewCard)
    {
        // Only do something if we're in the "pick a crew member" mode
        if (mCurrentMode == GameState.EncounterMode 
            && mCurrentEncounter.CanSelectCrew()
            && mCurrentEncounter.CanSelectCrewMember(crewCard.mCrewMember))
        {
            crewCard.ToggleSelected();
        }
    }

    public int GetNumSelectedCrew()
    {
        int numSelected = 0;
        foreach(Transform crewCardObj in mCrewGridContainer)
        {
            CrewGridEntry crewCard = crewCardObj.GetComponent<CrewGridEntry>();
            if(crewCard.IsSelected())
            {
                numSelected++;
            }
        }

        return numSelected;
    }

    public void CheckCrewStatus()
    {
        // If 0 crew, game over
        if(mCrew.Count == 0)
        {
            mCurrentMode = GameState.GameOver;

            // Show crew game over screen.
            mCrewGameOverScreen.SetActive(true);
        }

        // If 0 stability, game over
        if(mCurrentStability <= 0)
        {
            mCurrentMode = GameState.GameOver;
            mMutinyGameOverScreen.SetActive(true);
        }
    }

    public void RemoveSelectedCrew()
    {
        List<CrewMember> removedCrew = new List<CrewMember>();
        foreach (Transform crewCardObj in mCrewGridContainer)
        {
            CrewGridEntry crewCard = crewCardObj.GetComponent<CrewGridEntry>();
            if (crewCard.IsSelected())
            {
                removedCrew.Add(crewCard.mCrewMember);
                Destroy(crewCard.gameObject);
            }
        }

        foreach (CrewMember crewMember in removedCrew)
        {
            mCrew.Remove(crewMember);
        }
    }

    public void CloneSelectedCrew()
    {
        List<CrewMember> crew = new List<CrewMember>();
        foreach (Transform crewCardObj in mCrewGridContainer)
        {
            CrewGridEntry crewCard = crewCardObj.GetComponent<CrewGridEntry>();
            if (crewCard.IsSelected())
            {
                crew.Add(crewCard.mCrewMember);
            }
        }

        foreach (CrewMember oldCrewMember in crew)
        {
            CrewMember newMember = new CrewMember(oldCrewMember);
            AddCrewMember(newMember);
        }
    }

    public void KillSelectedCrew()
    {
        List<CrewMember> deadCrew = new List<CrewMember>();
        foreach (Transform crewCardObj in mCrewGridContainer)
        {
            CrewGridEntry crewCard = crewCardObj.GetComponent<CrewGridEntry>();
            if (crewCard.IsSelected())
            {
                deadCrew.Add(crewCard.mCrewMember);
            }
        }

        foreach (CrewMember crewMember in deadCrew)
        {
            OnCrewDied(crewMember);
        }
    }

    public void KillRandomCrewOfType(ClassType classType, int numToKill)
    {
        List<CrewMember> candidates = new List<CrewMember>();
        foreach(CrewMember crew in mCrew)
        {
            if(crew.mClass == classType || classType == ClassType.None)
            {
                candidates.Add(crew);
            }
        }

        for(int i = 0; i < numToKill; i++)
        {
            if(candidates.Count == 0)
            {
                break;
            }    

            int randomIndex = Random.Range(0, 100) % candidates.Count;
            CrewMember deadCrew = candidates[randomIndex];
            OnCrewDied(deadCrew);
            candidates.RemoveAt(randomIndex);
        }
    }

    public void OnCrewDied(CrewMember crewMember)
    {
        foreach (Transform crewCardObj in mCrewGridContainer)
        {
            CrewGridEntry crewCard = crewCardObj.GetComponent<CrewGridEntry>();
            if (crewCard.mCrewMember == crewMember)
            {
                Destroy(crewCard.gameObject);
            }
        }

        mCrew.Remove(crewMember);
        Log(crewMember.GetFullName() + " has died.", mBadTextColor);

        if (crewMember.HasTrait(TraitType.Telepsychopath))
        {
            // Pick another random crew member to kill.
            if (mCrew.Count > 0)
            {
                CrewMember target = mCrew[Random.Range(0, mCrew.Count)];
                Log(crewMember.GetFullName() + "'s telepathic kill switch activates!", mBadTextColor);
                OnCrewDied(target);
            }
        }
    }

    public void OnClickedOption(TextOption option)
    {
        mCurrentEncounter.OnClickedOption(option);
    }

    public void IncrementCredits(int amount)
    {
        mNumCredits += amount;
    }

    public int GetNumCredits()
    {
        return mNumCredits;
    }

    public void IncrementStability(int amount)
    {
        mCurrentStability += amount;

        if(mCurrentStability <= 0)
        {
            // Mutiny end condition.
            mCurrentMode = GameState.GameOver;

            mMutinyGameOverScreen.SetActive(true);
        }
    }

    public void OnClickedExitGame()
    {
        Application.Quit();
    }

    public void SpawnHelpWindow(string text)
    {
        mInfoPanel.SetActive(true);
        mInfoText.text = text;
    }

    public List<CrewMember> GetRandomCrewMembers(int num)
    {
        int randomIndex = Random.Range(0, mCrew.Count);
        List<CrewMember> picks = new List<CrewMember>();
        picks.Add(mCrew[randomIndex]);
        picks.Add(mCrew[(randomIndex + 1) % mCrew.Count]);

        return picks;
    }

    public bool HasCargo()
    {
        return mbHasCargo;
    }

    public void JettisonCargo()
    {
        mbHasCargo = false;
    }

    public void PickUpCargo(bool isContraband = false)
    {
        mbHasCargo = true;
        mbCargoIsContraband = isContraband;
        if (isContraband)
        {
            mCargoString = GetRandomContrabandString();
        }
        else
        {
            mCargoString = GetRandomCargoString();
        }
    }

    string GetRandomCargoString()
    {
        return "Cargo: " + Random.Range(1, 30) * 100 + " " + randomCargoUnit[Random.Range(0, randomCargoUnit.Length)] + " " + randomCargo[Random.Range(0, randomCargo.Length)];
    }

    string GetRandomContrabandString()
    {
        return "Cargo: " + Random.Range(1, 30) * 100 + " " + randomCargoUnit[Random.Range(0, randomCargoUnit.Length)] + " " + randomContraband[Random.Range(0, randomContraband.Length)];
    }

    // Sell cargo, recruit crew if below max
    public void OnArrivedFriendlyStar()
    {
        if(mbHasCargo)
        {
            float sellValue = 10;
            if(mbCargoIsContraband)
            {
                sellValue = 20;
            }

            foreach (CrewMember crew in mCrew)
            {
                if (crew.HasTrait(TraitType.Thief))
                {
                    sellValue = sellValue * 0.9f;
                }
            }

            IncrementCredits((int)sellValue);
        }

        PickUpCargo();

        if(GetNumCrew() < mMaxCrew)
        {
            AddNewRandomCrewMember();
        }
    }

    public void IncrementMaxCrew(int amt)
    {
        mMaxCrew += amt;
    }

    public void Log(string logString, Color color)
    {
        mEncounterLog.Add(new TextPlusColor(color, logString));
    }

    public List<CrewMember> GetCrew()
    {
        return mCrew;
    }
}
