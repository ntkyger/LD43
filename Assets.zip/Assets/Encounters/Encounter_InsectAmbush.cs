﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_InsectAmbush : Encounter {

    public override string GetEncounterTitle()
    {
        return "Ambush";
    }

    public override string GetEncounterText()
    {
        return "While scouting around a scuttled imperial destroyer, a proximity klaxon blares. Warlike insectoids ambush you, demanding two of your crew members for their nefarious purposes.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Give in to their demands, and send two of your choice (select 2 crew members from manifest).");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "(Requires 1 Security Officer): Fight them off. 1 random Security Officer will die in the assault.");
        textOption2.AddRequirement(new CrewNumRequirement(ClassType.Combat, 1));
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "(Requires 10 Combat Power): Slaughter the aliens (+10 credits).");
        textOption3.AddRequirement(new PowerRequirement(ClassType.Combat, 10));
        options.Add(textOption3);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;

        // 1: Pick 2 crew (spawn window to explain?)
        if (optionIndex == 1)
        {
            int numSelected = GameManager.mInstance.GetNumSelectedCrew();
            if (numSelected == 2 || (numSelected == 1 && numSelected == GameManager.mInstance.GetNumCrew()))
            {
                GameManager.mInstance.Log("The insectoids chitter happily. Your former crew members are escorted onto their ship in handcuffs.", Color.white);
                GameManager.mInstance.RemoveSelectedCrew();
                encounterEnded = true;
            }
            if(numSelected < 2)
            {
                // Spawn window
                string text = "Highlight two crew members by clicking their manifest entries. Once you're sure of your decision, select this option again.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
            else if(numSelected > 2)
            {
                // Spawn window
                string text = "Highlight only two crew members.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
        }

        // 2: Sacrifice 1 security
        if (optionIndex == 2)
        {
            GameManager.mInstance.Log("Your Security officers successfully fend off the attack. Unfortunately, one of them is fatally injured in the fight.", Color.white);
            GameManager.mInstance.KillRandomCrewOfType(ClassType.Combat, 1);
            encounterEnded = true;
        }

        // 3: Kill aliens
        if (optionIndex == 3)
        {
            GameManager.mInstance.IncrementCredits(10);
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return true;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
