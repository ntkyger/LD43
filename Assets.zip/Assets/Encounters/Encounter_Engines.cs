﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Engines : Encounter {

    public override string GetEncounterTitle()
    {
        return "Engine Failure";
    }

    public override string GetEncounterText()
    {
        return "Your engines suddenly shut down, leaving you stranded in space. It seems to be a problem with the cooling system.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Wait for someone to assist you (-10 Stability)");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Call for help (-5 Stability, -5 Credits)");
        textOption2.AddRequirement(new CreditsRequirement(5));
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "(Requires 5 Engineering) Fix the problem.");
        textOption3.AddRequirement(new PowerRequirement(ClassType.Engineer, 5));
        options.Add(textOption3);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Nothing
        if (optionIndex == 1)
        {
            GameManager.mInstance.Log("You are forced to wait until a good samaritan comes along and renders aid. Your crew thinks a bit less of you. (-10 Stability)", Color.white);
            gm.IncrementStability(-10);
            encounterEnded = true;
        }

        // 2: Trade
        if (optionIndex == 2)
        {
            GameManager.mInstance.Log("Help arrives quickly, and you're soon back on track. (-5 Stability, -5 Credits)", Color.white);
            gm.IncrementStability(-5);
            gm.IncrementCredits(-5);
            encounterEnded = true;
        }

        // 3: Fight
        if (optionIndex == 3)
        {
            GameManager.mInstance.Log("Your resourceful engineers identify the problem and quickly fix it.", Color.white);
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return false;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
