﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_OxygenLeak : Encounter {

    public override string GetEncounterTitle()
    {
        return "Oxygen Leak";
    }

    public override string GetEncounterText()
    {
        return "A life support sensor flickers. You discover a leak in the oxygen supply system; you've been slowly venting oxygen for hours. You have enough air to make it to the nearest resupply, but there's not enough for everyone...";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Kill 1 crew of your choice to ensure everyone else lives (-10 stability) (select 1 crew member from manifest).");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Don't sacrifice anyone (+10 stability, but a random crew member will die)");
        options.Add(textOption2);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;

        // 1: Pick 1 crew (spawn window to explain?)
        if (optionIndex == 1)
        {
            int numSelected = GameManager.mInstance.GetNumSelectedCrew();
            if (numSelected == 1)
            {
                GameManager.mInstance.Log("The selected crew member puts on a brave face as they are escorted to an airlock and sucked into space. The remainder of your crew look around nervously, wondering which of them might be next.", Color.white);
                GameManager.mInstance.KillSelectedCrew();
                encounterEnded = true;
            }
            if(numSelected < 1)
            {
                // Spawn window
                string text = "Highlight a crew member by clicking them. Once you're sure of your decision, select this option again.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
            else if(numSelected > 1)
            {
                // Spawn window
                string text = "Highlight only one crew member.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
        }

        // 2: Random crew dies
        if (optionIndex == 2)
        {
            GameManager.mInstance.KillRandomCrewOfType(ClassType.None, 1);
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return true;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
