﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_PsychicProbe : Encounter {

    public override string GetEncounterTitle()
    {
        return "Psychic Probe";
    }

    public override string GetEncounterText()
    {
        return "A probe enters your consciousness. It speaks directly into your brainstem, probing your mind for engineering knowledge. Your crew can see you wrestling with the thing.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Surrender your mind (-10 Stability)");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "(Requires 3 Engineering) Trade it for what it wants (-3 Stability, +5 Credits)");
        textOption2.AddRequirement(new PowerRequirement(ClassType.Engineer, 3));
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "(Requires 20 Empath) Fight off the psychic intruder (+5 stability)");
        textOption3.AddRequirement(new PowerRequirement(ClassType.Empath, 20));
        options.Add(textOption3);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Surrender
        if (optionIndex == 1)
        {
            GameManager.mInstance.Log("The probe picks through your brain. When it realizes you don't have what it's looking for, it leaves as suddenly as it arrived. (-10 Stability)", Color.white);
            gm.IncrementStability(-10);
            encounterEnded = true;
        }

        // 2: Trade
        if (optionIndex == 2)
        {
            GameManager.mInstance.Log("You manage to strike a deal with the intruder. (-3 Stability, +5 Credits)", Color.white);
            gm.IncrementStability(-3);
            gm.IncrementCredits(5);
            encounterEnded = true;
        }

        // 3: Fight
        if (optionIndex == 3)
        {
            GameManager.mInstance.Log("You manage to fight off the unwanted intruder. It is sent back to wherever it came from. (+5 Stability)", Color.white);
            GameManager.mInstance.IncrementStability(5);
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return false;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
