﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Raiders: Encounter {

    public override string GetEncounterTitle()
    {
        return "Raiders";
    }

    public override string GetEncounterText()
    {
        return "A raider ship pops up on the scanner. They're closing fast.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Surrender (1 random crew member will be killed)");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "(Requires 5 Combat) Fight off the raiders.");
        textOption2.AddRequirement(new PowerRequirement(ClassType.Combat, 5));
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "(Requires 8 Empath) Manipulate their minds into leaving you alone.");
        textOption3.AddRequirement(new PowerRequirement(ClassType.Empath, 8));
        options.Add(textOption3);

        GameObject option4 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption4 = option4.GetComponent<TextOption>();
        textOption4.Init(4, "(Requires 15 Engineering) Boost your ship's engines to escape.");
        textOption4.AddRequirement(new PowerRequirement(ClassType.Engineer, 15));
        options.Add(textOption4);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Surrender
        if (optionIndex == 1)
        {
            GameManager.mInstance.Log("The raiders quickly board you ship and execute one crew member to make an example for the rest.", Color.white);
            gm.KillRandomCrewOfType(ClassType.None, 1);
            encounterEnded = true;
        }

        // 2: Combat
        if (optionIndex == 2)
        {
            GameManager.mInstance.Log("You succeed in repelling the attack.", Color.white);
            encounterEnded = true;
        }

        // 3: Empath
        if (optionIndex == 3)
        {
            GameManager.mInstance.Log("The raider ship drifts away peacefully thanks to your Empaths.", Color.white);
            encounterEnded = true;
        }

        // 4: Engineering
        if (optionIndex == 4)
        {
            GameManager.mInstance.Log("You ship jolts into overdrive; the raiders are soon long gone.", Color.white);
            encounterEnded = true;
        }

        if (encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return false;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
