﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Rest_Shipyard: Encounter {

    int randomUpgradeCost;

    public Encounter_Rest_Shipyard()
    {
        randomUpgradeCost = Random.Range(20, 100);
    }

    public override string GetEncounterTitle()
    {
        return "Friendly Shipyard";
    }

    public override string GetEncounterText()
    {
        string text = "You arrive at a friendly shipyard. Here, massive trade vessels and cruise ships are constructed practically overnight. Welding torches flicker from every direction.";
        text += " Your ship gets a much-needed cleaning and tune-up.";

        if (GameManager.mInstance.HasCargo())
        {
            text += " You sell your cargo and pick up a new shipment.";
        }
        else
        {
            text += " You pick up a new shipment of cargo.";
        }

        if (GameManager.mInstance.GetNumCrew() <= GameManager.mInstance.GetMaxCrew())
        {
            text += " New recruits join your crew.";
        }

        return text;
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Upgrade ship (-" + randomUpgradeCost +  " credits, +3 crew slots)");
        textOption.AddRequirement(new CreditsRequirement(randomUpgradeCost));
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Leave.");
        options.Add(textOption2);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;

        // 1: Upgrade ship
        if (optionIndex == 1)
        {
            GameManager.mInstance.IncrementCredits(-randomUpgradeCost);
            GameManager.mInstance.IncrementMaxCrew(3);
            encounterEnded = true;
        }

        // 2: Leave
        if (optionIndex == 2)
        {
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return false;
    }

    public override bool IsRestEncounter()
    {
        return true;
    }
}
