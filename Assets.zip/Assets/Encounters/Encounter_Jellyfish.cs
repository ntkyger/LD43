﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Jellyfish : Encounter {

    public override string GetEncounterTitle()
    {
        return "Rare Beast";
    }

    public override string GetEncounterText()
    {
        return "You encounter a rare life form, a celestial jellyfish. It appears to be caught in a weak magnetic field.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Harvest the beast for its valuable organs (-5 stability, +10 credits)");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Leave the beast alone (-2 stability)");
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "(Requires 5 Engineering) Free the creature (+5 stability)");
        textOption3.AddRequirement(new PowerRequirement(ClassType.Engineer, 5));
        options.Add(textOption3);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Harvest
        if (optionIndex == 1)
        {
            GameManager.mInstance.Log("You slay the beast and slice it up. These organs will fetch a decent price on the market. (+10 Credits, -5 Stability)", Color.white);
            gm.IncrementCredits(10);
            gm.IncrementStability(-5);
            encounterEnded = true;
        }

        // 2: Leave
        if (optionIndex == 2)
        {
            GameManager.mInstance.Log("Unable to help, you leave the beast to its own devices. (-2 Stability)", Color.white);
            gm.IncrementStability(-2);
            encounterEnded = true;
        }

        // 3: Kill aliens
        if (optionIndex == 3)
        {
            GameManager.mInstance.Log("Your engineers manage to pry the beast free from the magnetic field. It worbles happily at you as it drifts away into the distance. (+5 Stability)", Color.white);
            GameManager.mInstance.IncrementStability(5);
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return false;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
