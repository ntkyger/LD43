﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Tribe: Encounter {

    public override string GetEncounterTitle()
    {
        return "Native Tribe";
    }

    public override string GetEncounterText()
    {
        return "You encounter an indigenous tribe armed with primitive technology. They ask for credits.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Give them nothing (-2 Stability)");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "(Requires 20 credits) Give them credits (+5 Stability, -20 Credits)");
        textOption2.AddRequirement(new CreditsRequirement(20));
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "(Requires 5 Combat) Fight them and take what little they have (-9 Stability, +10 Credits)");
        textOption3.AddRequirement(new PowerRequirement(ClassType.Combat, 5));
        options.Add(textOption3);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Nothing
        if (optionIndex == 1)
        {
            GameManager.mInstance.Log("The tribe looks disappointed, but the accept your decision without complaint. (-2 Stability)", Color.white);
            gm.IncrementStability(-2);
            encounterEnded = true;
        }

        // 2: Trade
        if (optionIndex == 2)
        {
            GameManager.mInstance.Log("You graciously donate a decent number of credits. (+5 Stability, -20 Credits)", Color.white);
            gm.IncrementStability(5);
            gm.IncrementCredits(-20);
            encounterEnded = true;
        }

        // 3: Fight
        if (optionIndex == 3)
        {
            GameManager.mInstance.Log("You seize their posessions. The tribespeople - and some members of your crew - appear outraged at this betrayal. (-9 Stability, +10 Credits)", Color.white);
            GameManager.mInstance.IncrementStability(-9);
            GameManager.mInstance.IncrementCredits(10);
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return false;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
