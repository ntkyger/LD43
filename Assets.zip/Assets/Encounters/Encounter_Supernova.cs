﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Supernova : Encounter {

    public Encounter_Supernova()
    {
    }

    public override string GetEncounterTitle()
    {
        return "Supernova";
    }

    public override string GetEncounterText()
    {
        return "A nearby star is undergoing an unexpected supernova. You're carrying too much weight and can't accelerate fast enough to escape.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "(Requires Cargo): Jettison all cargo.");
        textOption.AddRequirement(new CargoRequirement());
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Jettison a chosen crew member (-10 stability) (select 1 crew member from manifest).");
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "(Requires 10 Engineering Power): Your technicians have come up with an alternate solution: buy engine boost components from a nearby ship (-5 credits)");
        textOption3.AddRequirement(new PowerRequirement(ClassType.Engineer, 10));
        textOption3.AddRequirement(new CreditsRequirement(5));
        options.Add(textOption3);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Jettison cargo
        if (optionIndex == 1)
        {
            GameManager.mInstance.Log("As the last of your cargo crates whooshes out into space, your crew breathes a collective sigh of relief.", Color.white);
            gm.JettisonCargo();
            encounterEnded = true;
        }

        // 2: Jettison crew
        if (optionIndex == 2)
        {
            int numSelected = gm.GetNumSelectedCrew();
            if (numSelected == 1)
            {
                GameManager.mInstance.Log("The selected crew member puts on a brave face as they are escorted to an airlock and sucked into space. The remainder of your crew look around nervously, wondering which of them might be next.", Color.white);
                gm.KillSelectedCrew();
                encounterEnded = true;
            }
            if (numSelected < 1)
            {
                // Spawn window
                string text = "Highlight a crew member by clicking their manifest entry. Once you're sure of your decision, select this option again.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
            else if (numSelected > 1)
            {
                // Spawn window
                string text = "Highlight only one crew member.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
        }

        // 3: Buy supplies
        if (optionIndex == 3)
        {
            gm.IncrementCredits(-5);
            encounterEnded = true;
        }

        if (encounterEnded)
        {
            gm.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return true;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
