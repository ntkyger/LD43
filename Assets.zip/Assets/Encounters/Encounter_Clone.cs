﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Clone : Encounter {

    public Encounter_Clone()
    {

    }

    public override string GetEncounterTitle()
    {
        return "Cloning Facility";
    }

    public override string GetEncounterText()
    {
        return "You discover a hidden cloning facility. The work they're doing here is highly suspect; they are eager to reward you for keeping your mouth shut.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Accept their offer to clone one of your crew members (select a crew member from manifest)");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Accept their offer of 15 credits");
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "Decline their offers (+5 stability)");
        options.Add(textOption3);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Clone crew
        if (optionIndex == 1)
        {
            int numSelected = GameManager.mInstance.GetNumSelectedCrew();
            if (numSelected == 1)
            {
                GameManager.mInstance.Log("The cloners are grateful for your discretion. A couple of hours later, a goo-covered clone rises from one of their bubbling vats and joins your crew.", Color.white);
                GameManager.mInstance.CloneSelectedCrew();
                encounterEnded = true;
            }
            if (numSelected < 1)
            {
                // Spawn window
                string text = "Highlight a crew member by clicking on them. Once you're sure of your decision, select this option again.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
            else if (numSelected > 1)
            {
                // Spawn window
                string text = "Highlight only one crew member.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
        }

        // 2: Take the money
        if (optionIndex == 2)
        {
            gm.IncrementCredits(15);
            encounterEnded = true;
        }

        // 3: Decline offers
        if (optionIndex == 3)
        {
            gm.IncrementStability(5);
            encounterEnded = true;
        }

        if (encounterEnded)
        {
            gm.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return true;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
