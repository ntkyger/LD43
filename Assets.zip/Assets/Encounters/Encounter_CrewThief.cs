﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_CrewThief : Encounter {

    public int mGuiltyParty;
    public CrewMember mSuspect1;
    public CrewMember mSuspect2;

    public Encounter_CrewThief()
    {
        // Pick two random suspects from crew.
        List<CrewMember> crew = GameManager.mInstance.GetRandomCrewMembers(2);
        mSuspect1 = crew[0];
        mSuspect2 = crew[1];

        mGuiltyParty = Random.Range(0, 2);
    }

    public override string GetEncounterTitle()
    {
        return "Betrayal from within";
    }

    public override string GetEncounterText()
    {
        return "Loot has been going missing, and the crew suspects someone is skimming off the top. The list is narrowed down to two suspects, but neither confesses.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Kill suspect A: "+ mSuspect1.mFirstName + " " + mSuspect1.mLastName + " (+10 stability and +10 credits if you're right, -10 stability if you're wrong)");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Kill suspect B: " + mSuspect2.mFirstName + " " + mSuspect2.mLastName + " (+10 stability and +10 credits if you're right, -10 stability if you're wrong)");
        options.Add(textOption2);

        GameObject option3 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption3 = option3.GetComponent<TextOption>();
        textOption3.Init(3, "Kill neither (-5 stability)");
        options.Add(textOption3);

        GameObject option4 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption4 = option4.GetComponent<TextOption>();
        textOption4.Init(4, "Kill them both to make an example (+10 credits, -10 stability)");
        options.Add(textOption4);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Pick suspect 1
        if (optionIndex == 1)
        {
            gm.OnCrewDied(mSuspect1);
            if(mGuiltyParty == 0)
            {
                GameManager.mInstance.Log("Luckily, you executed the correct suspect. Your crew breathes a sigh of relief (+10 stability, +10 credits).", Color.white);
                gm.IncrementStability(10);
                gm.IncrementCredits(10);
            }
            else
            {
                GameManager.mInstance.Log("Unfortunately, you executed the wrong suspect (-10 stability). Having seen their crewmate killed in cold blood, the offender swears on their life to never steal again.", Color.white);
                gm.IncrementStability(-10);
            }
            encounterEnded = true;
        }

        // 2: Pick suspect 2
        if (optionIndex == 2)
        {
            gm.OnCrewDied(mSuspect2);
            if (mGuiltyParty == 1)
            {
                GameManager.mInstance.Log("Luckily, you executed the correct suspect. Your crew breathes a sigh of relief (+10 stability, +10 credits).", Color.white);
                gm.IncrementStability(10);
                gm.IncrementCredits(10);
            }
            else
            {
                GameManager.mInstance.Log("Unfortunately, you executed the wrong suspect (-10 stability). Having seen their crewmate killed in cold blood, the offender swears on their life to never steal again.", Color.white);
                gm.IncrementStability(-10);
            }
            encounterEnded = true;
        }

        // 3: Kill neither
        if (optionIndex == 3)
        {
            gm.IncrementStability(-5);
            encounterEnded = true;
        }

        // 3: Kill both
        if (optionIndex == 4)
        {
            gm.OnCrewDied(mSuspect1);
            gm.OnCrewDied(mSuspect2);
            gm.IncrementStability(-10);
            gm.IncrementCredits(10);
            encounterEnded = true;
        }

        if (encounterEnded)
        {
            gm.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return false;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
