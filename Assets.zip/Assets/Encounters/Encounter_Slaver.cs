﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_Slaver : Encounter {

    public override string GetEncounterTitle()
    {
        return "Slave Ship";
    }

    public override string GetEncounterText()
    {
        return "A slave ship approaches warily. They ask if you would be interested in selling any of your crew.";
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption = option1.GetComponent<TextOption>();
        textOption.Init(1, "Give them 1 crew of your choice (-10 stability, +10 credits) (select 1 crew member from manifest).");
        options.Add(textOption);

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "Decline their offer.");
        options.Add(textOption2);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;

        // 1: Pick 1 crew (spawn window to explain?)
        if (optionIndex == 1)
        {
            int numSelected = GameManager.mInstance.GetNumSelectedCrew();
            if (numSelected == 1)
            {
                GameManager.mInstance.Log("The slavers greedily take command of your former crew member, and pay handsomely (+10 credits, -10 stability).", Color.white);
                GameManager.mInstance.RemoveSelectedCrew();
                GameManager.mInstance.IncrementStability(-10);
                GameManager.mInstance.IncrementCredits(10);
                encounterEnded = true;
            }
            if(numSelected < 1)
            {
                // Spawn window
                string text = "Highlight a crew member by clicking them. Once you're sure of your decision, select this option again.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
            else if(numSelected > 1)
            {
                // Spawn window
                string text = "Highlight only one crew member.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
        }

        // 2: Nothing happens
        if (optionIndex == 2)
        {
            encounterEnded = true;
        }

        if(encounterEnded)
        {
            GameManager.mInstance.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return true;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
