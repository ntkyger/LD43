﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter_AlienTagResearch : Encounter {

    public TraitType mTrait;

    public Encounter_AlienTagResearch()
    {
        // Pick random trait that aliens are interested in.
        List<TraitType> mTraits = new List<TraitType>();
        foreach(CrewMember crewMember in GameManager.mInstance.GetCrew())
        {
            foreach(TraitType trait in crewMember.mTraits)
            {
                mTraits.Add(trait);
            }
        }

        if (mTraits.Count > 0)
        {
            int randomIndex = Random.Range(0, mTraits.Count);
            mTrait = mTraits[randomIndex];
        }
    }

    public override string GetEncounterTitle()
    {
        return "Alien Research";
    }

    public override string GetEncounterText()
    {
        if (mTrait != TraitType.None)
        {
            return "You are accosted by a group of telepathic mad scientists. Their voices chitter in your brain, bending your free will. They demand you hand over a crew member with the " + GameManager.mInstance.GetTraitName(mTrait) + " trait, for research purposes.";
        }
        else
        {
            return "You are accosted by a group of telepathic mad scientists. Their voices chitter in your brain, bending your free will. They demand you hand over a crew member for 'research' purposes.";
        }
    }

    public override List<TextOption> GetOptions()
    {
        List<TextOption> options = new List<TextOption>();

        if (mTrait != TraitType.None)
        {
            GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
            TextOption textOption = option1.GetComponent<TextOption>();
            textOption.Init(1, "Give them a " + GameManager.mInstance.GetTraitName(mTrait) + " crew member (select a crew member from manifest)");
            options.Add(textOption);
        }
        else
        {
            GameObject option1 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
            TextOption textOption = option1.GetComponent<TextOption>();
            textOption.Init(1, "Give them a crew member (select a crew member from manifest)");
            options.Add(textOption);
        }

        GameObject option2 = GameObject.Instantiate(GameManager.mInstance.Option_TextPrefab);
        TextOption textOption2 = option2.GetComponent<TextOption>();
        textOption2.Init(2, "(Requires 1 Empath): Resist their mind control. 1 random Empath will die in the process.");
        textOption2.AddRequirement(new CrewNumRequirement(ClassType.Empath, 1));
        options.Add(textOption2);

        return options;
    }

    public override void OnClickedOption(TextOption option)
    {
        int optionIndex = option.mIndex;
        bool encounterEnded = false;
        GameManager gm = GameManager.mInstance;

        // 1: Give up crew with tag
        if (optionIndex == 1)
        {
            int numSelected = GameManager.mInstance.GetNumSelectedCrew();
            if (numSelected == 1)
            {
                GameManager.mInstance.Log("You feel a calming euphoria wash over you. The crew members you selected walk peacefully onto the science vessel, seemingly of their own free will.", Color.white);
                GameManager.mInstance.RemoveSelectedCrew();
                encounterEnded = true;
            }
            if (numSelected < 1)
            {
                // Spawn window
                string text = "Highlight a crew member by clicking on them. Once you're sure of your decision, select this option again.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
            else if (numSelected > 1)
            {
                // Spawn window
                string text = "Highlight only one crew members.";
                GameManager.mInstance.SpawnHelpWindow(text);
            }
        }

        // 2: Sacrifice 1 empath
        if (optionIndex == 2)
        {
            GameManager.mInstance.Log("Your Empaths successfully fight off the pirates. Unfortunately, the mental strain is too much for one of them.", Color.white);
            GameManager.mInstance.KillRandomCrewOfType(ClassType.Empath, 1);
            encounterEnded = true;
        }

        if (encounterEnded)
        {
            gm.OnExitedEncounter();
        }
    }

    public override bool CanSelectCrew()
    {
        return true;
    }

    public override bool CanSelectCrewMember(CrewMember crewMember)
    {
        if (mTrait != TraitType.None)
        {
            return crewMember.HasTrait(mTrait);
        }

        return true;
    }

    public override bool IsRestEncounter()
    {
        return false;
    }
}
