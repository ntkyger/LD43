﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class StarTooltipComponent : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler {

    public Star mStar;
    public float mHoverStartTime;
    float mTooltipDelay = 0.2f;

    public void OnPointerEnter(PointerEventData eventData)
    {
        mHoverStartTime = Time.realtimeSinceStartup;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        mHoverStartTime = 0;
        GameManager.mInstance.DeactivateTooltip();
    }

    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () 
    {
        if (mHoverStartTime != 0)
        {
            // The mouse is over the button. Show the tooltip after some period of time.
            if (Time.realtimeSinceStartup > mHoverStartTime + mTooltipDelay)
            {
                GameManager.mInstance.ActivateTooltip(mStar);
            }
        }
    }
}
