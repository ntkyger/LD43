﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CrewGridEntry : MonoBehaviour {

    public CrewMember mCrewMember;

    public Text mLastNameText;
    public Text mFirstNameText;
    public RaceTooltipComponent mRacePanel;
    public Text mRaceText;
    public Text mClassText;

    public GameObject mSelectedOverlay;
    public GameObject mSelectedCheckmark;

    // Traits
    public TraitTooltipComponent mTrait1;
    public Image mTrait1Image;
    public Text mTrait1Name;
    public Text mTrait1Subtitle;
    public Text mEmptySlot1Text;

    public TraitTooltipComponent mTrait2;
    public Image mTrait2Image;
    public Text mTrait2Name;
    public Text mTrait2Subtitle;
    public Text mEmptySlot2Text;

    public TraitTooltipComponent mTrait3;
    public Image mTrait3Image;
    public Text mTrait3Name;
    public Text mTrait3Subtitle;
    public Text mEmptySlot3Text;

    bool mbIsSelected;

    public void Init(CrewMember crewMember)
    {
        mCrewMember = crewMember;

        mLastNameText.text = crewMember.mLastName + ",";
        mFirstNameText.text = crewMember.mFirstName;
        mRaceText.text = crewMember.GetRaceText();

        TextPlusColor classText = crewMember.GetClassText();
        mClassText.text = classText.mText;
        mClassText.color = classText.mColor;

        mRacePanel.mRace = crewMember.mRace;

        List<TraitType> traits = crewMember.mTraits;
        if(traits.Count > 0)
        {
            // Show slot 1
            mTrait1Image.gameObject.SetActive(true);
            mTrait1Name.gameObject.SetActive(true);
            mTrait1Subtitle.gameObject.SetActive(true);
            mEmptySlot1Text.gameObject.SetActive(false);

            TraitType trait = traits[0];
            mTrait1.mTrait = trait;
            mTrait1Image.sprite = GameManager.mInstance.GetTraitSprite(trait);
            mTrait1Name.text = GameManager.mInstance.GetTraitName(trait);
            TextPlusColor subtitle = GameManager.mInstance.GetTraitSubtitle(trait, crewMember);
            mTrait1Subtitle.text = subtitle.mText;
            mTrait1Subtitle.color = subtitle.mColor;
        }
        else
        {
            // Hide slot 1
            mTrait1Image.gameObject.SetActive(false);
            mTrait1Name.gameObject.SetActive(false);
            mTrait1Subtitle.gameObject.SetActive(false);
            mEmptySlot1Text.gameObject.SetActive(true);
        }

        if (traits.Count > 1)
        {
            // Show slot 2
            mTrait2Image.gameObject.SetActive(true);
            mTrait2Name.gameObject.SetActive(true);
            mTrait2Subtitle.gameObject.SetActive(true);
            mEmptySlot2Text.gameObject.SetActive(false);

            TraitType trait = traits[1];
            mTrait2.mTrait = trait;
            mTrait2Image.sprite = GameManager.mInstance.GetTraitSprite(trait);
            mTrait2Name.text = GameManager.mInstance.GetTraitName(trait);
            TextPlusColor subtitle = GameManager.mInstance.GetTraitSubtitle(trait, crewMember);
            mTrait2Subtitle.text = subtitle.mText;
            mTrait2Subtitle.color = subtitle.mColor;
        }
        else
        {
            // Hide slot 2
            mTrait2Image.gameObject.SetActive(false);
            mTrait2Name.gameObject.SetActive(false);
            mTrait2Subtitle.gameObject.SetActive(false);
            mEmptySlot2Text.gameObject.SetActive(true);
        }

        if (traits.Count > 2)
        {
            // Show slot 3
            mTrait3Image.gameObject.SetActive(true);
            mTrait3Name.gameObject.SetActive(true);
            mTrait3Subtitle.gameObject.SetActive(true);
            mEmptySlot3Text.gameObject.SetActive(false);

            TraitType trait = traits[2];
            mTrait3.mTrait = trait;
            mTrait3Image.sprite = GameManager.mInstance.GetTraitSprite(trait);
            mTrait3Name.text = GameManager.mInstance.GetTraitName(trait);
            TextPlusColor subtitle = GameManager.mInstance.GetTraitSubtitle(trait, crewMember);
            mTrait3Subtitle.text = subtitle.mText;
            mTrait3Subtitle.color = subtitle.mColor;
        }
        else
        {
            // Hide slot 3
            mTrait3Image.gameObject.SetActive(false);
            mTrait3Name.gameObject.SetActive(false);
            mTrait3Subtitle.gameObject.SetActive(false);
            mEmptySlot3Text.gameObject.SetActive(true);
        }
    }

    public void OnClicked()
    {
        GameManager.mInstance.OnClickedCrewCard(this);
    }

    public void ToggleSelected()
    {
        mbIsSelected = !mbIsSelected;

        if(mbIsSelected)
        {
            mSelectedOverlay.SetActive(true);
            mSelectedCheckmark.SetActive(true);
        }
        else
        {
            mSelectedOverlay.SetActive(false);
            mSelectedCheckmark.SetActive(false);
        }
    }

    public bool IsSelected()
    {
        return mbIsSelected;
    }

	// Update is called once per frame
	void Update () {
        Init(mCrewMember);
	}
}
