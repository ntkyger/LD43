﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Encounter {

    public virtual string GetEncounterTitle()
    {
        return null;
    }

    public virtual string GetEncounterText()
    {
        return null;
    }

    public virtual bool CanSelectCrew()
    {
        return false;
    }

    public virtual bool CanSelectCrewMember(CrewMember crewMember)
    {
        return true;
    }

    public virtual List<TextOption> GetOptions()
    { return null; }

    public virtual void OnClickedOption(TextOption option) { }

    public virtual bool IsRestEncounter() { return false; }
}
