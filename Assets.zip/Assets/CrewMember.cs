﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum RaceType
{
    None,
    Human,
    Insectoid,
    Cthulian,
    Reptilian,

    Max
}

public enum ClassType
{
    None,
    Combat,
    Engineer,
    Empath,

    Max
}

public enum TraitType 
{
    None,
    Lazy,
    Diligent,
    NaturalWarrior,
    NaturalEmpath,
    NaturalTechnician,
    Racist,
    Xenophile,
    Thief,
    Antisocial,
    Lonely,
    PoorHygiene,
    Telepsychopath,
    BrainWormHost,
    Insane,
    Narcissist,
    Counselor,
    Sexy,
    Jealous,
    Confident,

    Max
}

public class CrewMember {

    public string mLastName;
    public string mFirstName;
    public RaceType mRace;

    public ClassType mClass;
    public int mClassLevel;

    public CrewGridEntry mCard;

    static string[] FirstNames = { "Benjamin", "Damian", "Marcus", "Winston", "Harvey", "Cash", "Sawyer", "Theodore", "Jason", "Amitabh", "Jayadeva", "Ranjit", "Ragoba", "Aakash ", "Viswarupa", "Raghu", "Govind", "Tom", "Dominic", "Mickael", "Hubert", "Justin", "Adrius", "Bellarmin", "Aloysiau", "Tobi", "Vladémir", "Theodoros", "Stefanos", "Nikitas", "Spiros", "Nikolas", "Fokionas", "Alekos", "Themistoklis", "Ioannis", "Aristis", "Skylar", "Afli", "Kails", "Istreal", "Yel", "Zroc", "Uthaendu", "Oklaxix", "Duan" };
    static string[] LastNames = { "Zheng", "Pulos", "Metaxas", "Makos", "Anastos", "Nanos", "Vallis", "Papas", "Karahalios", "Mingas", "Tomaras", "Hogue", "Dugas", "Boutin", "Gordon", "Grimard", "Robert", "Soucy", "Lemaire", "Prince", "Hoffman", "Stewart", "Fessenden", "Piers", "Robins", "Newton", "Scott", "McCrae", "Gale", "Staples", "Upadhyay", "Dhebar", "Vyas", "Divakar", "Jagatap", "Valimbe", "Chattarak", "Nayar", "Pavagi", "Nan", "Soulières", "Knox" };

    public List<TraitType> mTraits;

	// Use this for initialization
	public CrewMember () {
        mTraits = new List<TraitType>();

        mLastName = LastNames[Random.Range(0, LastNames.Length)];
        mFirstName = FirstNames[Random.Range(0, FirstNames.Length)];

        int raceInt = Random.Range(1, (int)RaceType.Max);
        mRace = (RaceType)raceInt;

        int classInt = Random.Range(1, (int)ClassType.Max);
        mClass = (ClassType)classInt;
        mClassLevel = 1;
    }

    public CrewMember(CrewMember clone)
    {
        mTraits = new List<TraitType>();

        mLastName = clone.mLastName;
        mFirstName = clone.mFirstName;

        mRace = clone.mRace;

        mClass = clone.mClass;
        mClassLevel = clone.mClassLevel;

        foreach(TraitType trait in clone.mTraits)
        {
            mTraits.Add(trait);
        }
    }

    public string GetFullName()
    {
        return mFirstName + " " + mLastName;
    }

    public TextPlusColor GetClassText()
    {
        string text = "Level " + mClassLevel + " " + GameManager.mInstance.GetClassName(mClass) + " (+" + GetEffectiveClassPoints() + ")";
        Color color = GameManager.mInstance.GetClassColor(mClass);
        return new TextPlusColor(color, text);
    }

    public int GetNumTraits()
    {
        return mTraits.Count;
    }

    public TraitType GainRandomTrait()
    {
        TraitType trait = TraitType.None;

        // Cannot have duplicate traits.
        while (trait == TraitType.None || HasTrait(trait))
        {
            int randomTraitInt = Random.Range(1, (int)TraitType.Max);
            trait = (TraitType)randomTraitInt;
        }

        mTraits.Add(trait);
        return trait;
    }

    public int GetEffectiveClassPoints()
    {
        int points = mClassLevel;
        if(mTraits.Contains(TraitType.Lazy))
        {
            points = points / 2;
        }
        if(mTraits.Contains(TraitType.Insane))
        {
            points = points * 2;
        }

        return points;
    }

    public int GetTotalClassPoints(ClassType classType)
    {
        int totalPoints = 0;
        if(classType == mClass)
        {
            totalPoints += GetEffectiveClassPoints();

            if (HasTrait(TraitType.Diligent))
            {
                totalPoints += 1;
            }
        }

        if(classType == ClassType.Combat && HasTrait(TraitType.NaturalWarrior))
        {
            totalPoints += 1;
        }
        
        if(classType == ClassType.Empath && HasTrait(TraitType.NaturalEmpath))
        {
            totalPoints += 1;
        }

        if(classType == ClassType.Engineer && HasTrait(TraitType.NaturalTechnician))
        {
            totalPoints += 1;
        }

        return totalPoints;
    }

    public bool HasTrait(TraitType traitType)
    {
        return mTraits.Contains(traitType);
    }

    public void TryAddBrainWorms()
    {
        if(mTraits.Count < 3)
        {
            mTraits.Add(TraitType.BrainWormHost);
        }
        else
        {
            // Replace a trait.
            mTraits.RemoveAt(Random.Range(0, mTraits.Count));
            mTraits.Add(TraitType.BrainWormHost);
        }
    }

    public string GetRaceText()
    {
        switch(mRace)
        {
            case RaceType.Human:
                return "H";
            case RaceType.Insectoid:
                return "I";
            case RaceType.Reptilian:
                return "R";
            case RaceType.Cthulian:
                return "C";
        }

        return "N";
    }
}
