﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum StarType
{
    None,
    EdenWorld,
    AsteroidBelt,
    GasGiant,
    FrozenExoplanet,
    Nebula,

    Max
}

public class Star : MonoBehaviour {

    public Image mImage;
    public RectTransform mParentLine;
    Star mParentStar;
    public List<Star> mChildStars;
    public string mName;
    public StarTooltipComponent mTooltip;

    StarType mType;

	// Use this for initialization
	public void Init () {
        int randomTypeInt = Random.Range(1, (int)StarType.Max);
        mType = (StarType)randomTypeInt;

        mImage.color = GetStarColor(mType);
        mParentLine.gameObject.SetActive(false);

        mChildStars = new List<Star>();

        string[] alphabet = new string[26] { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" };
        mName = GetBaseName() + " " + alphabet[Random.Range(0, alphabet.Length)] + Random.Range(0, 999);

        mTooltip.mStar = this;
    }

    public void SetParentStar(Star star)
    {
        mParentStar = star;
        mParentLine.gameObject.SetActive(true);
        Vector3 starMidpoint = (star.transform.position + transform.position) / 2f;
        mParentLine.transform.position = starMidpoint;
        Vector3 diff = star.transform.position - transform.position;
        float angle = Mathf.Atan(diff.y / diff.x);
        mParentLine.Rotate(new Vector3(0, 0, Mathf.Rad2Deg * angle));
    }

    public void OnClicked()
    {
        GameManager.mInstance.OnClickedStar(this);
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public Encounter GetEncounter()
    {
        // Different stars spawn different types of encounters.
        switch (mType)
        {
            case StarType.EdenWorld:
                return GetEdenEncounter();
            case StarType.AsteroidBelt:
            case StarType.FrozenExoplanet:
            case StarType.GasGiant:
            case StarType.Nebula:
                return GetHostileEncounter();
        }

        return null;
    }

    Encounter GetEdenEncounter()
    {
        int randomIndex = Random.Range(0, 3);
        switch(randomIndex)
        {
            case 0:
                return new Encounter_Rest_BanditBase();
            case 1:
                return new Encounter_Rest_Paradise();
            case 2:
                return new Encounter_Rest_Shipyard();
        }

        return null;
    }

    Encounter GetHostileEncounter()
    {
        int randomIndex = Random.Range(0, 13);
        switch (randomIndex)
        {
            case 0:
                return new Encounter_AlienTagResearch();
            case 1:
                return new Encounter_Clone();
            case 2:
                return new Encounter_CrewThief();
            case 3:
                return new Encounter_InsectAmbush();
            case 4:
                return new Encounter_OxygenLeak();
            case 5:
                return new Encounter_Slaver();
            case 6:
                return new Encounter_Supernova();
            case 7:
                return new Encounter_TelepathPirates();
            case 8:
                return new Encounter_Raiders();
            case 9:
                return new Encounter_Jellyfish();
            case 10:
                return new Encounter_PsychicProbe();
            case 11:
                return new Encounter_Tribe();
            case 12:
                return new Encounter_Engines();
        }

        return null;
    }

    public string GetBaseName()
    {
        string text = "";
        switch (mType)
        {
            case StarType.AsteroidBelt:
                text += "Asteroid Belt";
                break;
            case StarType.EdenWorld:
                text += "Eden World";
                break;
            case StarType.FrozenExoplanet:
                text += "Frozen Exoplanet";
                break;
            case StarType.GasGiant:
                text += "Gas Giant";
                break;
            case StarType.Nebula:
                text += "Nebula";
                break;
        }

        return text;
    }

    Color GetStarColor(StarType starType)
    {
        switch (mType)
        {
            case StarType.AsteroidBelt:
                return new Color(0.8f, 0.4f, 0.4f);
            case StarType.EdenWorld:
                return new Color(0.4f, 0.8f, 0.4f);
            case StarType.FrozenExoplanet:
                return new Color(0.4f, 0.4f, 0.8f);
            case StarType.GasGiant:
                return new Color(0.8f, 0.8f, 0.4f);
            case StarType.Nebula:
                return new Color(0.8f, 0.4f, 0.8f);
        }

        return Color.white;
    }
}
