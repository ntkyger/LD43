﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextPlusColor {

    public Color mColor;
    public string mText;

    public TextPlusColor(Color color, string text)
    {
        mColor = color;
        mText = text;
    }
}
